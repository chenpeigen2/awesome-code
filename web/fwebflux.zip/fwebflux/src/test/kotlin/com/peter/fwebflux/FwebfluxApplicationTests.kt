package com.peter.fwebflux

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FwebfluxApplicationTests {

	@Test
	fun contextLoads() {
	}

}
