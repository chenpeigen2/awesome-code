package com.peter.wweb

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WwebApplicationTests {

	@Test
	fun contextLoads() {
	}

}
